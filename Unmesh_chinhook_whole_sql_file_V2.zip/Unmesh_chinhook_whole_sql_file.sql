-- Objective question 1 ) 1.	Does any table have missing values or duplicates? If yes how would you handle it ?

SELECT customer_id,first_name,
	case when company is null then 'INDIPENDANT/NOT AVAILABLE' else company     end as  company,address,city,
	case when state is null then 'NOT AVAILABLE'               else state       end as  state ,country,
    case when postal_code is null then 'NOT AVAILABLE'         else postal_code end as  postal_code,
    case when phone is null then 'NOT AVAILABLE'               else phone       end as  phone,
    case when fax is null then 'NOT AVAILABLE'                 else fax         end as  fax,email,support_rep_id
          
FROM chinook.customer
-- -------------------

select track_id,name,album_id,media_type_id,genre_id, 
			case when composer is null then 'NOT AVAILABLE' else composer end as composer,
            milliseconds,bytes,unit_price
from track t
-- -------------------------------------------------------------------------------------------------------
-- 2.	Find the top-selling tracks and top artist in the USA and identify their most famous genres.

select a.name as Artist_name ,il.track_id,t.name as track_name, i.billing_country,count(i.invoice_id) number_of_tracks_sold,g.name as Genre_name
from invoice i
	join invoice_line  il on i.invoice_id=il.invoice_id
	join track t  on il.track_id= t.track_id
	join album al on t.album_id = al.album_id
	join artist a on al.artist_id=a.artist_id
	join genre g on t.genre_id=g.genre_id
where billing_country = 'USA'
group by track_id,billing_country,Genre_name
order by count(i.invoice_id) desc
limit 2 
-- ----------------------------------------------------------------------------------------------------------------
-- 3.	What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?

-- ANS ) On the basis of location. we have 2 categories , Country and city 
 
SELECT   c.country ,count(c.customer_id) as number_of_customers  
FROM chinook.customer c
	join invoice i on c.customer_id=i.customer_id
group by c.country
order by count(c.customer_id)  desc ,c.country
-- -------------
SELECT   c.country,c.city, count(c.customer_id) as number_of_customers
FROM chinook.customer c
	join invoice i on c.customer_id=i.customer_id
group by c.country,c.city
order by c.country,count(c.customer_id)  desc ,c.city
-- --------------
SELECT   c.city,count(c.customer_id) as number_of_customers
FROM chinook.customer c
	join invoice i on c.customer_id=i.customer_id
group by c.city
order by count(c.customer_id)  desc 
-- -----------------------------------------------------------------------------------------------------------
-- 4.	Calculate the total revenue and number of invoices for each country, state, and city:

select billing_country as country ,billing_state as state, billing_city as city,count(il.invoice_id) as number_of_invoices , sum(unit_price*quantity) as total_revenue 
from invoice i
    join invoice_line il on i.invoice_id=il.invoice_id 
group by country,state, city
-- ------------------------------------------------------------------------------------------------------------
-- 5.	Find the top 5 customers by total revenue in each country

with temp as (
select i.customer_id,billing_country as country , sum(unit_price*quantity) as total_revenue 
from invoice i
    join invoice_line il on i.invoice_id=il.invoice_id 
group by i.customer_id,country
order by total_revenue desc
),
ranked_temp as (
select customer_id,country,total_revenue,
	dense_rank() over(partition by country order by total_revenue desc) as ranking
from temp
) 
select rt.customer_id,concat(c.first_name,' ',c.last_name) as full_name ,rt.country,rt.total_revenue ,rt.ranking
from ranked_temp  rt
	join customer c on rt.customer_id=c.customer_id 
where ranking <= 5
order by rt.country,rt.ranking
-- ----------------------------------------------------------------------------------------------------
-- 6.	Identify the top-selling track for each customer
with temp  as (
select c.customer_id,concat(c.first_name,' ',c.last_name) as full_name,il.track_id,t.name as track_name,count(i.invoice_id) number_of_tracks_sold
from invoice i
	join invoice_line  il on i.invoice_id=il.invoice_id
    join customer c on i.customer_id=c.customer_id
    join track t on il.track_id=t.track_id

group by c.customer_id,concat(c.first_name,' ',c.last_name),il.track_id
),
temp2 as (

select t.*,
	rank() over(partition by full_name order by number_of_tracks_sold desc) as top_selling_track_rank
from temp t
)
select t2.*
from temp2 t2
where top_selling_track_rank = 1
-- ------------------------------------------------------------------------------------------------------
-- 7.	Are there any patterns or trends in customer purchasing behavior 
-- (e.g., frequency of purchases, preferred payment methods, average order value)?


-- preffered media type of customers
select mt.name as media_type_used , count(c.customer_id) as number_of_customers
from media_type mt
	join track t                on mt.media_type_id=t.media_type_id
    join invoice_line il        on t.track_id= il.track_id
    join invoice i              on il.invoice_id = i.invoice_id
    join customer c             on i.customer_id = c.customer_id
group by media_type_used
order by count(c.customer_id) desc

-- total purchases of customers over the years 
with fy as (
select sum(i.total) as yearwise_total_purchases
from customer c
	join invoice i on c.customer_id =i.customer_id
where i.invoice_date < '2017-12-30'
),
sy as (
select sum(i.total) as second_year_total_purchases
from customer c
	join invoice i on c.customer_id =i.customer_id
where i.invoice_date between  '2017-12-30' and'2018-12-30'
),
ty as (
select sum(i.total) as third_year_total_purchases
from customer c
	join invoice i on c.customer_id =i.customer_id
where i.invoice_date between  '2018-12-30' and '2019-12-30'
),
foy as (
select sum(i.total) as fourth_year_total_purchases
from customer c
	join invoice i on c.customer_id =i.customer_id
where i.invoice_date between   '2019-12-30' and '2020-12-30'
),
 temp2 as (
select * from fy
union all 
select * from sy
union all 
select * from ty
union all 
select * from foy 
)

select avg(yearwise_total_purchases) as AVG_YEAR_WISE_PURCHASES from temp2

-- ---------------------------------------------------------------------------------------------------------------
-- 8.	What is the customer churn rate?
with first_year_customers as (
select customer_id, invoice_date
from invoice i 
where invoice_date between '2017-01-03'and '2017-12-17'
order by invoice_date 
),
second_year_customers as (
select customer_id, invoice_date
from invoice i 
where invoice_date between '2018-01-02'and '2018-12-26'
order by invoice_date 
),
third_year_customers as (
select customer_id, invoice_date
from invoice i 
where invoice_date between '2019-01-01'and '2019-12-31'
order by invoice_date 
),
fourth_year_customers as (
select customer_id, invoice_date
from invoice i 
where invoice_date between '2020-01-12'and '2020-12-30'
order by invoice_date 
),

first_year_non_returning_customers as (
select distinct fy.customer_id as fy_non_returning_customers
from first_year_customers fy
where not exists        (select 1
						from second_year_customers sy
                        where fy.customer_id=sy.customer_id)
),
 second_year_non_returning_customers as (
select distinct sy.customer_id as sy_non_returning_customers
from second_year_customers sy 
where not exists (select 1
				  from third_year_customers ty 
                  where sy.customer_id=ty.customer_id)
) ,
third_year_non_returning_customers as (
 select distinct ty.customer_id as ty_non_returning_customers
 from third_year_customers ty
 where not exists (select fo.customer_id
				   from fourth_year_customers fo 
                   where ty.customer_id=fo.customer_id)
 ),
 total_non_returning_customers as (
 
 select * from first_year_non_returning_customers
 union all 
 select * from second_year_non_returning_customers
 union all 
 select * from third_year_non_returning_customers
)

select count( fy_non_returning_customers)*100/59 as churn_rate
from total_non_returning_customers

-- ---------------------------------------------------------------------------------------------------------------
-- 9.	Calculate the percentage of total sales contributed by each genre in the USA 
--      and identify the best-selling genres and artists.

with temp as (
select g.genre_id,g.name,sum(i.total) as total_sales
from genre g
	join track t          on g.genre_id=t.genre_id
    join invoice_line il  on t.track_id = il.track_id
    join invoice i        on il.invoice_id=i.invoice_id
where i.billing_country = 'USA'
group by g.genre_id,g.name
order by total_sales desc
)

select genre_id,t.name as genre_name,total_sales,
total_sales/(select sum(total_sales) from temp t )*100  as percentage_contribution
from temp t
group by genre_id, genre_name,total_sales
-- ---------------------------------------------------------------------------------------------------------------
-- 10.	Find customers who have purchased tracks from at least 3 different genres

select i.customer_id,concat(first_name,' ',last_name) as full_name, count( distinct g.genre_id) as genre_count
from genre g
	join track t          on g.genre_id=t.genre_id
    join invoice_line il  on t.track_id = il.track_id
    join invoice i        on il.invoice_id=i.invoice_id
    join customer c       on c.customer_id=i.customer_id
group by i.customer_id,full_name
having count(distinct g.genre_id)>=3
order by genre_count desc
-- ----------------------------------------------------------------------------------------------------------------
-- 11.	Rank genres based on their sales performance in the USA


with temp as (
select g.genre_id,g.name as genre_name,sum(i.total) as total_sales
from genre g 
join track t              on g.genre_id=t.genre_id
join invoice_line il      on t.track_id = il.track_id
join invoice i            on il.invoice_id=i.invoice_id
where i.billing_country = 'USA'
group by g.genre_id, genre_name
)
select t.* ,
		dense_rank() over(order by total_sales desc) as ranking
from temp t 
order by ranking
-- --------------------------------------------------------------------------------------------------------------
-- 12.	Identify customers who have not made a purchase in the last 3 months
with temp as (

select i.customer_id ,concat(first_name,' ',last_name) as full_name
from customer c
	join invoice i on i.customer_id=c.customer_id
where i.invoice_date > (select distinct date_sub('2020-12-30',INTERVAL 3 MONTH)
						from invoice i)
)
select c.customer_id,concat(first_name,' ',last_name) as full_name 
from customer c 
where not exists (select 1
				  from temp t 
                  where t.customer_id = c.customer_id)
-- --------------------------------------------------------------------------------------------------------------
-- OBJECTIVE QUESTIONS END --------------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------------------------------------



-- SUBJECTIVE QESTIONS ------------------------------------------------------------------------------------------
-- -----------------------------------------------------------==>>

 --  1. Recommend the three albums from the new record label that 
 --    should be prioritised for advertising and promotion in the USA based 
 --    on genre sales analysis.

select a.album_id , a.title as Album_Name,g.genre_id,g.name as genre_name,count(il.invoice_id) as number_of_sales 
from album a 
	join track t             on a.album_id=t.album_id
    join genre g             on t.genre_id = g.genre_id
    join invoice_line il     on t.track_id = il.track_id
    join invoice i           on il.invoice_id = i.invoice_id
 where billing_country ='USA'   

group by a.album_id , a.title,g.genre_id,genre_name
order by count(il.invoice_id) desc
limit 3
-- --------------------------------------------------------------------------------------------------------------------------
-- 2.	Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.

select g.genre_id,g.name as genre_name,i.billing_country,count(g.genre_id) as number_of_times_genre_sold 
from album a 
	join track t             on a.album_id=t.album_id
    join genre g             on t.genre_id = g.genre_id
    join invoice_line il     on t.track_id = il.track_id
    join invoice i           on il.invoice_id = i.invoice_id
 where billing_country <>'USA'   

group by g.genre_id, genre_name,i.billing_country
order by  count(g.genre_id) desc

-- --------------------------------------------------------------------------------------------------------------------------

-- 3.	Customer Purchasing Behavior Analysis: How do the purchasing habits
-- (frequency, basket size, spending amount) of long-term customers differ from those of new customers? 
--  What insights can these patterns provide about customer loyalty and retention strategies?



with temp1 as (
select i.customer_id,max(invoice_date) as latest_date ,min(invoice_date) as oldest_date
from invoice i  
group by i.customer_id
),
temp2 as (
select t.*, timestampdiff(month,t.oldest_date,t.latest_date) as tenure_in_months
      from temp1 t 
order by tenure_in_months desc
)
select customer_id ,tenure_in_months ,
	   case when tenure_in_months >=30 then "Older customer"
	   else "newer customer"
       end as customer_status
from temp2 

-- --------- 
with table1 as (
				with customer_freq as (
						select  i.customer_id,il.invoice_id ,count(il.track_id) as  no_of_tracks_bought_together
							from invoice i
							join invoice_line il on i.invoice_id=il.invoice_id
							join customer c on c.customer_id = i.customer_id

						group by i.customer_id,i.invoice_id
						order by no_of_tracks_bought_together desc , customer_id 
						),
				ranked as (
							select customer_id, invoice_id ,no_of_tracks_bought_together,
							dense_rank() over(partition by customer_id order by no_of_tracks_bought_together desc) as ranking
							from customer_freq 
							),
				maximum_bucket as (
							select customer_id,invoice_id,no_of_tracks_bought_together as max_bucket_size
							from ranked 
							where ranking = 1
							)
							select distinct customer_id,max_bucket_size
							from maximum_bucket
),



table2 as (
          select customer_id, count(invoice_id) as Frequency_over_3years
          from (select  i.customer_id,il.invoice_id ,count(il.track_id) as  no_of_tracks_bought_together
                from invoice i
	            join invoice_line il on i.invoice_id=il.invoice_id
				join customer c on c.customer_id = i.customer_id
				group by i.customer_id,i.invoice_id
				order by  customer_id ) x 
		 group by customer_id
		 order by customer_id
),

table3 as (select customer_id, sum(total) as total_spending_amount
			from invoice 
			group by customer_id
			order by customer_id
)

select t1.customer_id,t2.Frequency_over_3years,t1.max_bucket_size,t3.total_spending_amount
from table1 t1 
	join table2 t2 on t1.customer_id = t2.customer_id
    join table3 t3 on t1.customer_id = t3.customer_id
where t1.customer_id in (5,6,8,56)
    
-- ----------------------------------------------------------------------------------------------------------
-- 4.	Product Affinity Analysis: Which music genres, artists,
-- or albums are frequently purchased together by customers?
-- How can this information guide product recommendations and cross-selling initiatives?

with temp1 as (
select   il.invoice_id,  g.genre_id,g.name as genre_name
from genre g 
	join track t         on g.genre_id=t.genre_id
    join invoice_line il on t.track_id =il.track_id
    join invoice i       on il.invoice_id=i.invoice_id
    join customer c      on i.customer_id=c.customer_id
)

SELECT 
    t1.genre_name as genre1,t2.genre_name as genre2,count(*) as no_times_bought_in_pairs
from temp1 t1
join temp1 t2 on t1.invoice_id = t2.invoice_id and t1.genre_id < t2.genre_id  
group by genre1,genre2
order by  no_times_bought_in_pairs desc
-- ----------
with temp1 as (
select i.invoice_id,al.album_id, al.title as album_name 
from artist ar 
	join album al        on ar.artist_id= al.artist_id
    join track t         on t.album_id = al.album_id
    join invoice_line il on t.track_id =il.track_id
    join invoice i       on il.invoice_id=i.invoice_id
    join customer c      on i.customer_id=c.customer_id
)
select t1.album_name as album1 , t2.album_name as album2,count(*) as no_of_albums_bought_together
from temp1 t1
	join temp1 t2 on t1.invoice_id= t2.invoice_id and t1.album_id < t2.album_id
group by album1,album2
order by count(*) desc 
-- ----------------------
with temp1 as (
select i.invoice_id, ar.artist_id,ar.name as artist_name
from artist ar 
	join album al        on ar.artist_id= al.artist_id
    join track t         on t.album_id = al.album_id
    join invoice_line il on t.track_id =il.track_id
    join invoice i       on il.invoice_id=i.invoice_id
    join customer c      on i.customer_id=c.customer_id
)
select t1.artist_name as artist1 , t2.artist_name as artist2,count(*) as no_of_artists_bought_together
from temp1 t1
	join temp1 t2 on t1.invoice_id= t2.invoice_id and t1.artist_id < t2.artist_id
group by artist1,artist2
order by count(*) desc 


-- --------------------------------------------------------------------------------------------------------
-- 5.Regional Market Analysis: Do customer purchasing behaviors (spending ammount,frequency,basket size)
--  and churn rates vary across different geographic regions or store locations?
--  How might these correlate with local demographic or economic factors?

with location_wise_spending_habits as (

select c.city,c.country,count(i.invoice_id) as no_of_purchases,sum(i.total) as total_amount_spent
from customer c
join invoice i ON c.customer_id = i.customer_id
group by  c.city, c.country
order by total_amount_spent DESC
 ), 
 
 max_bucket_size as (
              with customer_freq as (
						select  i.customer_id,c.country,il.invoice_id ,count(il.track_id) as  no_of_tracks_bought_together
							from invoice i
							join invoice_line il on i.invoice_id=il.invoice_id
							join customer c on c.customer_id = i.customer_id

						group by i.customer_id,i.invoice_id,c.country
						order by no_of_tracks_bought_together desc , customer_id 
						),
				ranked as (
							select customer_id,country, invoice_id ,no_of_tracks_bought_together,
							dense_rank() over(partition by customer_id order by no_of_tracks_bought_together desc) as ranking
							from customer_freq 
							),
				maximum_bucket as (
							select customer_id,country,invoice_id,no_of_tracks_bought_together as max_bucket_size
							from ranked 
							where ranking = 1
							)
							select distinct customer_id,country,max_bucket_size
							from maximum_bucket
) 

select    lh.city,  lh.country, lh.no_of_purchases,lh.total_amount_spent,max(mbz.max_bucket_size) as max_bucket_size
from location_wise_spending_habits lh
	join max_bucket_size mbz on lh.country=mbz.country
group by lh.city,  lh.country, lh.no_of_purchases,lh.total_amount_spent
order by total_amount_spent desc,max_bucket_size desc,no_of_purchases desc,country asc

-- -----------
-- for churn rate :

with lastest_customers as (
select c.customer_id,c.city,c.country,max(i.invoice_date) as latest_invoice_date
from customer c 
	left join invoice i on c.customer_id=i.customer_id
group by c.customer_id,c.city,c.country
),
 no_of_churned_customers as (
select city,country,count(*) as no_of_churned_customers
from lastest_customers lc
where latest_invoice_date < date_sub("2020-12-30", interval 6 month)
group by city,country
),
total_customers as (
select city,country,count(*) as total_no_of_customers
from customer c
group by city,country
)
select tc.city,tc.country,no_of_churned_customers,total_no_of_customers,
	case when no_of_churned_customers is  null then 0 
		 else (no_of_churned_customers/total_no_of_customers)*100
         end as churn_rate
		
from total_customers tc 
	 left join no_of_churned_customers cc   on tc.city=cc.city
     
-- ---------------------------------------------------------------------------------------
-- 6.	Customer Risk Profiling: Based on customer profiles
-- (age, gender, location, purchase history), which customer segments
-- are more likely to churn or pose a higher risk of reduced spending?
-- What factors contribute to this risk?



with table1 as (


with location_wise_spending_habits as (

select c.country,count(i.invoice_id) as no_of_purchases,sum(i.total) as total_amount_spent
from customer c
join invoice i ON c.customer_id = i.customer_id
where i.invoice_date> date_sub("2020-12-30",interval 1.5 year)
group by   c.country
order by total_amount_spent DESC
 ), 
 
 max_bucket_size as (
              with customer_freq as (
						select  i.customer_id,c.country,il.invoice_id ,count(il.track_id) as  no_of_tracks_bought_together
							from invoice i
							join invoice_line il on i.invoice_id=il.invoice_id
							join customer c on c.customer_id = i.customer_id

						group by i.customer_id,i.invoice_id,c.country
						order by no_of_tracks_bought_together desc , customer_id 
						),
				ranked as (
							select customer_id,country, invoice_id ,no_of_tracks_bought_together,
							dense_rank() over(partition by customer_id order by no_of_tracks_bought_together desc) as ranking
							from customer_freq 
							),
				maximum_bucket as (
							select customer_id,country,invoice_id,no_of_tracks_bought_together as max_bucket_size
							from ranked 
							where ranking = 1
							)
							select distinct customer_id,country,max_bucket_size
							from maximum_bucket
) 

select      lh.country, lh.no_of_purchases,lh.total_amount_spent,max(mbz.max_bucket_size) as max_bucket_size
from location_wise_spending_habits lh
	join max_bucket_size mbz on lh.country=mbz.country
group by   lh.country, lh.no_of_purchases,lh.total_amount_spent
order by total_amount_spent desc,max_bucket_size desc,no_of_purchases desc,country asc

),



table2 as (

with lastest_customers as (
select c.customer_id,c.city,c.country,max(i.invoice_date) as latest_invoice_date
from customer c 
	left join invoice i on c.customer_id=i.customer_id
group by c.customer_id,c.city,c.country
),
 no_of_churned_customers as (
select country,count(*) as no_of_churned_customers
from lastest_customers lc
where latest_invoice_date < date_sub("2020-12-30", interval 6 month)
group by country
),
total_customers as (
select country,count(*) as total_no_of_customers
from customer c
group by country
)
select tc.country,no_of_churned_customers,total_no_of_customers,
	case when no_of_churned_customers is  null then 0 
		 else (no_of_churned_customers/total_no_of_customers)*100
         end as churn_rate
		
from total_customers tc 
	 left join no_of_churned_customers cc   on tc.country=cc.country
 )

select t1.country,t1.no_of_purchases,t1.total_amount_spent,t1.max_bucket_size,t2.churn_rate,
	  case when churn_rate = 100 then 'High Risk'
		   when churn_rate = 0   then 'No Risk'
           when churn_rate > 30 and total_amount_spent >130 then 'Moderate Risk'
           else 'Low Risk'
	  end as regional_risk 
from table1 t1
    join table2 t2 on t1.country=t2.country
    
    
-- ---------------------------------------------------------------------------------------
-- 7.	Customer Lifetime Value Modeling: 
-- How can you leverage customer data (tenure, purchase history, engagement) 
-- to predict the lifetime value of different customer segments? 
-- This could inform targeted marketing and loyalty program strategies. 
-- Can you observe any common characteristics or purchase patterns among customers 
-- who have stopped purchasing?
with AVG_ORDER_VALUE as (
	with temp1 as (
	select billing_country,sum(total) as total_order_value
	from invoice i 
	group by billing_country
	)
	select billing_country as country,total_order_value/(select sum(total_order_value) from temp1) as AVG_order_value
	from temp1
),
 AVG_PURCHASE_COUNT as (
	with total_purchases as (
	select billing_country as country, count(invoice_id) as total_purchases	
	from invoice
	group by country									
	)
	select country, total_purchases/(select sum(total_purchases) from total_purchases) as AVG_purchase_count
	from total_purchases
),
 AVG_TENURE as (

	with max_tenure as (

	select customer_id,billing_country as country , timestampdiff(month,min(invoice_date),max(invoice_date)) as tenure
	from invoice
	group by customer_id,country
	order by country
		)

	select customer_id,country,tenure,
		avg(tenure) over(partition by country range between unbounded preceding and unbounded following) as avg_tenure
	from  max_tenure 
) 

select  distinct aov.country,AVG_order_value* AVG_purchase_count*avg_tenure*100 as CLV
from AVG_ORDER_VALUE aov 
	join AVG_PURCHASE_COUNT apc on aov.country=apc.country
    join AVG_TENURE ten         on aov.country=ten.country
order by CLV desc

-- -------------------------------------------------------------------------------------

-- 11.	Chinook is interested in understanding the purchasing behavior of customers based on their geographical location.
-- They want to know the average total amount spent by customers from each country, along with the number of customers 
-- and the average number of tracks purchased per customer. Write an SQL query to provide this information.

with table1 as (

		select billing_country as country,
				avg(total) as AVG_order_amount, count(distinct customer_id) as customer_count
		from invoice i
		group by country
),


table2 as (

		with temp1 as (

		select i.billing_country as country,i.customer_id,count(t.track_id) as track_count_per_customer
		from invoice i 
		join invoice_line il on i.invoice_id=il.invoice_id
		join track t on il.track_id = t.track_id 
		group by i.customer_id,i.billing_country
		order by country
		),
		AVG_TRACKS_PURCHASED_PER_CUSTOMER as (

		select country,customer_id,track_count_per_customer,
		avg(track_count_per_customer) over(partition by country range between unbounded preceding and unbounded following) as AVG_tracks_purchased
		from temp1 
		group by country,customer_id
		)
		select distinct country,AVG_tracks_purchased
		from AVG_TRACKS_PURCHASED_PER_CUSTOMER 
)

select t1.country,AVG_order_amount,customer_count,AVG_tracks_purchased
from table1 t1
	join table2 t2 on t1.country=t2.country
order by country 
 
 
 -- -----------------------------------------------------------------------------------------------------------------------------------------------
 
 -- 10.	How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER to store the release year of each album?

alter table album 
add column ReleaseYear int ;

update album
set ReleaseYear = case 
    when album_id = 1 then -- 'release year'
    when album_id = 2 then -- 'release year'
    when album_id = 3 then -- 'release year'
    when album_id = 4 then -- 'release year'
    -- so on 
    else ReleaseYear  end;
    
    -- the release year is not given in database but if it was given then this is how i would do it 

-- ------------------------------------------------------------------------------------------------------------------------------------------
-- SUBJECTIVE QUESTIONS END -----------------------------------------------------------------------------------------------------------------
-- ------------------------------------------------------------------------------------------------------------------------------------------


		